// ================= LOGIN SYSTEM ==================
function loginUser(event) {
  event.preventDefault(); // prevent form submit
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;

  if (username === "admin" && password === "1234") {
    localStorage.setItem("loggedInUser", username);
    window.location.href = "dashboard.html";
  } else {
    let errorMsg = document.getElementById("error-msg");
    if (errorMsg) errorMsg.innerText = "❌ Invalid Username or Password!";
  }
}

// ================= LOGOUT ==================
function logoutUser() {
  alert("You have been logged out!");
  localStorage.removeItem("loggedInUser");
  localStorage.removeItem("cart"); // clear cart
  window.location.href = "login.html";
}

// ================= CART SYSTEM ==================
function addToCart(name, price) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push({ name, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(name + " added to cart!");
}

function loadCart() {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let cartItems = document.getElementById("cart-items");
  let totalPrice = 0;
  cartItems.innerHTML = "";

  cart.forEach((item, index) => {
    let li = document.createElement("li");
    li.innerHTML = `${item.name} - ₹${item.price} <button onclick="removeFromCart(${index})">❌ Remove</button>`;
    cartItems.appendChild(li);
    totalPrice += item.price;
  });

  let totalElem = document.getElementById("total-price");
  if (totalElem) totalElem.innerText = "Total: ₹" + totalPrice;
}

function removeFromCart(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  loadCart();
}

// load cart automatically on cart.html
if (window.location.pathname.includes("cart.html")) {
  window.onload = loadCart;
}

// ================= ORDER SYSTEM ==================
function placeOrder(event) {
  event.preventDefault();

  let name = document.getElementById("fullname").value;
  let email = document.getElementById("email").value;
  let address = document.getElementById("address").value;
  let phone = document.getElementById("phone").value;

  if (name && email && address && phone) {
    localStorage.setItem("customer", JSON.stringify({ name, email, address, phone }));
    window.location.href = "order-summary.html";
  } else {
    alert("Please fill all details before placing order!");
  }
}

function loadOrderSummary() {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let customer = JSON.parse(localStorage.getItem("customer")) || {};

  let customerElem = document.getElementById("customer-details");
  if (customerElem) {
    customerElem.innerHTML = `<b>Name:</b> ${customer.name}<br>
                              <b>Email:</b> ${customer.email}<br>
                              <b>Address:</b> ${customer.address}<br>
                              <b>Phone:</b> ${customer.phone}`;
  }

  let orderItems = document.getElementById("order-items");
  let total = 0;
  orderItems.innerHTML = "";

  cart.forEach(item => {
    let li = document.createElement("li");
    li.innerText = `${item.name} - ₹${item.price}`;
    orderItems.appendChild(li);
    total += item.price;
  });

  let totalElem = document.getElementById("final-total");
  if (totalElem) totalElem.innerText = "Total: ₹" + total;

  localStorage.removeItem("cart"); // clear cart after summary
}

// load order summary on order-summary.html
if (window.location.pathname.includes("order-summary.html")) {
  window.onload = loadOrderSummary;
}
